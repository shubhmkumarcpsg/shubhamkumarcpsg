/* tslint:disable */
require("./Matterform.module.css");
const styles = {
  matterform: 'matterform_8f30427a',
  container: 'container_8f30427a',
  row: 'row_8f30427a',
  column: 'column_8f30427a',
  'ms-Grid': 'ms-Grid_8f30427a',
  title: 'title_8f30427a',
  subTitle: 'subTitle_8f30427a',
  description: 'description_8f30427a',
  button: 'button_8f30427a',
  label: 'label_8f30427a'
};

export default styles;
/* tslint:enable */