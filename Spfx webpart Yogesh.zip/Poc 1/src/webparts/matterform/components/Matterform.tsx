import * as React from 'react';
import styles from './Matterform.module.scss';
import { IMatterformProps } from './IMatterformProps';
import { PrimaryButton, TextField,MessageBar, MessageBarType } from 'office-ui-fabric-react';
import { Dropdown, DropdownMenuItemType, IDropdownStyles, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
import { sp } from '@pnp/sp';
import { autobind, IPersonaProps } from 'office-ui-fabric-react';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
//import { getGUID } from '@pnp/common';
import { IUserDetail,IItemId } from './IMatterformState';
import { IListItem } from '../../mattergridview/components/IMattergridviewState';
import { Item } from '@pnp/sp/items';
//import { Items } from '@pnp/sp/items';
//import { DescriptionFieldLabel } from 'ClientformWebPartStrings';



const dropdownStyles: Partial<IDropdownStyles> = {
  dropdown: { width: 300 },
};


//  const projectlookupvalues = [
//    { key: 'CV', text: 'CV' },
//    { key: 'VE', text: 'VE' },
//    { key: 'OT', text: 'OT' },

//  ];

const AL = [
  { key: 'Tax law', text: 'Tax law' },
  { key: 'Intellectual property law', text: 'Intellectual property law' },
  { key: 'Contract law', text: 'Contract law' },

];

const MS = [
  { key: 'Open', text: 'Open' },
  { key: 'Close', text: 'Close' },

];


export default class Matterform extends React.Component<IMatterformProps, any> {


  constructor(props: IMatterformProps, state: any) {
   
    super(props);
  //  this.handleClick = this.handleClick.bind(this);
    this.state = {
      listitemsid:{},
      projectlookupvalues: {},
      // seletedprojects: null ,
      CreateNewDocumentForm: {},
      _onChangeDropdown: {},
      showMessageBar: false,
      MatterNumber:'',
    };

    this._getLookupvalues();
    this._getId();
    this._queryurl();
    
  }


  public render(): React.ReactElement<IMatterformProps> {

    return (
      <div className={styles.matterform}>

        <label>New Matter</label>
         <TextField label="Matter Number" required
          id="MatterNumber"
          onChange={this._inputUpdate}
          value = {"0000" + (this.state.listitemsid.ID + 1)}
        //  readOnly
       // value = {this.state.ids}  
        disabled
        />


        <Dropdown
          placeholder="Selcet Client Name"
          label="Client Name"
          id="AR_ClientName"
          options={this.state.projectlookupvalues}
          selectedKey={this.state.CreateNewDocumentForm.AR_ClientName ? this.state.CreateNewDocumentForm.AR_ClientName.key : undefined}
          defaultSelectedKey={this.state.CreateNewDocumentForm.AR_ClientName}
          onChange={this._onChangeDropdown}
          styles={dropdownStyles}
          required
          />

        <PeoplePicker
          context={this.props.context}
          titleText="Assigned Lawyer"
          personSelectionLimit={1}
          groupName={""} // Leave this blank in case you want to filter from all users    
          showtooltip={true}
          isRequired={true}
          disabled={false}
          ensureUser={true}
          selectedItems={this._getPeoplePickerItems}
          showHiddenInUI={false}
          principalTypes={[PrincipalType.User]}
          resolveDelay={1000} />

        <TextField label="Matters Description" required multiline rows={3} id="MattersDescription" onChange={this._inputUpdate} />

        <TextField label="Matter Name" id="MatterName" required onChange={this._inputUpdate} />


        <Dropdown
          placeholder="Selcet Area of law"
          label="Area of Law"
          id="AR_AriaOfLaw"
          options={AL}
          selectedKey={this.state.CreateNewDocumentForm.AR_AriaOfLaw ? this.state.CreateNewDocumentForm.AR_AriaOfLaw.key : undefined}
          defaultSelectedKey={this.state.CreateNewDocumentForm.AR_AriaOfLaw}
          onChange={this._onChangeDropdown}
          required
          styles={dropdownStyles} />

        <Dropdown
          placeholder="Selcet Matter status"
          label="Matter status"
          id="AR_MatterStatus"
          options={MS}
          selectedKey={this.state.CreateNewDocumentForm.AR_MatterStatus ? this.state.CreateNewDocumentForm.AR_MatterStatus.key : undefined}
          defaultSelectedKey={this.state.CreateNewDocumentForm.AR_MatterStatus}
          onChange={this._onChangeDropdown}
          required
          styles={dropdownStyles} /><br></br>


        <PrimaryButton text="Submit" allowDisabledFocus disabled={false} onClick={()=>{this._btnclick(Item);}}       />

      </div>
    );
  }

//   @autobind
//   public _uniqueid () : any {
// let ids = '0000';
// var len = this.state.listitemsid.ID.length ;


//     if (len.length == 1  ){
//    ids = '0000' + (this.state.listitemsid.ID + 1 );
// } else if (this.state.listitemsid.ID.length == 2  ){
//   ids = '0000' + (this.state.listitemsid.ID + 1 );
// } 

//   }

@autobind
public async _queryurl(){
  
  var qurl = window.location.href.split('?')[1].split('=')[1].toString() ;

} 

@autobind
public async _btnclick(item:any){
if (this.state.MatterNumber == item.Id)
{
  
  this._updateClicked(item);
}
else{
  this.createItem();
}
}

@autobind
public async _updateClicked(item: IListItem) {
  
  const updatedItem = await sp.web.lists.getByTitle("AR_Matter").items.getById(item.Id).select("AR_MatterName").update({
    MatterName:this.state.AR_MatterName,
  });

}


  @autobind
  public async _getId() {
    const listitems: any = await sp.web.lists.getByTitle("AR_Matter").items.select("ID").top(1).orderBy ("ID",false).get();
   var idarr : IItemId[] = [] ;

   listitems.forEach(itemid => {
idarr.push({ID: itemid});       
    });

    this.setState({ listitemsid: idarr[0].ID });
//    this._uniqueid();
  }

  @autobind
  private async _getLookupvalues() {
    const allItems: any[] = await sp.web.lists.getByTitle("AR_Clients").items.select("Id", "AR_ClientName").getAll();

    var projectarr: IDropdownOption[] = [];

    allItems.forEach(data => {
      projectarr.push({ key: data.Id, text: data.AR_ClientName });

    });
    this.setState({ projectlookupvalues: projectarr });

  }


  @autobind
  private _getPeoplePickerItems(items: any[]) {
    let userarr: IUserDetail[] = [];
    items.forEach(user => {
      userarr.push({ Id: user.id });
    });
    this.setState({ UserDetails: userarr[0] });

  }

  private _onChangeDropdown = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {
    var CreateNewDocumentForm = this.state.CreateNewDocumentForm;
    CreateNewDocumentForm[event.target["id"]] = item;
    this.setState({ CreateNewDocumentForm: CreateNewDocumentForm });

  }


  private _inputUpdate = e => {
    var createNewDocumentForm = this.state.CreateNewDocumentForm;
    createNewDocumentForm[e.target.id] = e.target.value,
      this.setState({
        MyForm: createNewDocumentForm
      });
      
  }


  @autobind
  private async createItem() {
   
    try {
      await sp.web.lists.getByTitle('AR_Matter').items.add({
        //AR_MatterNumber: this.state.CreateNewDocumentForm.MatterNumber,
         AR_MatterNumber: this.state.listitemsid.ID + 1,
         AR_LawyerAssignId: this.state.UserDetails.Id,
         AR_MattersDescription: this.state.CreateNewDocumentForm.MattersDescription,
         AR_MatterName: this.state.CreateNewDocumentForm.MatterName,
         AR_AriaOfLaw: this.state.CreateNewDocumentForm.AR_AriaOfLaw.key,
         AR_MatterStatus: this.state.CreateNewDocumentForm.AR_MatterStatus.key,
         AR_ClientNameId: this.state.CreateNewDocumentForm.AR_ClientName.key

      });

      this.setState({
        message: "Item:  - created successfully!",
        showMessageBar: true,
        messageType: MessageBarType.success
      });
    }
    catch (error) {
      this.setState({
        message: "Item  creation failed with error: " + error,
        showMessageBar: true,
        messageType: MessageBarType.error
      });
    }
  }

}
