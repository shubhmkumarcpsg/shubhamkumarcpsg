declare interface IMatterformWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MatterformWebPartStrings' {
  const strings: IMatterformWebPartStrings;
  export = strings;
}
