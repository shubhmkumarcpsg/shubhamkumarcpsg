declare interface IGridviewWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GridviewWebPartStrings' {
  const strings: IGridviewWebPartStrings;
  export = strings;
}
