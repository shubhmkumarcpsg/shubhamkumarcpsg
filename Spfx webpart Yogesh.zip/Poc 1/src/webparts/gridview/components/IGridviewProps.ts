export interface IGridviewProps {
  description: string;
  context:any;
}
