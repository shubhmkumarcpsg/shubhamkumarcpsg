import * as React from 'react';
import styles from './Gridview.module.scss';
import { IGridviewProps } from './IGridviewProps';
import { IGridviewstate } from './IGridviewstate';
import { ListView, IViewField, SelectionMode } from "@pnp/spfx-controls-react/lib/ListView";
import { sp } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";



export default class Gridview extends React.Component<IGridviewProps, any> {

  constructor(props: IGridviewProps, state: any) {
    super(props);
    this.state = {
      items: {},
    };
    var _viewFields: IViewField[] = [

      {
        name: "AR_ClientName",
        displayName: "ClientName",
        sorting: true,
        minWidth: 90,

      },
      {
        name: "AR_ClientAddress",
        displayName: "ClientAddress",
        sorting: true,
        minWidth: 90,

      },

      {
        name: "AR_ClientStatus",
        displayName: "ClientStatus",
        minWidth: 90,
        sorting: true,

      },
      {
        name: "AR_CompanyNumber",
        displayName: "CompanyNumber",
        sorting: true,
        minWidth: 100,
      },

      {
        name: "AR_ContactEmail",
        displayName: "ContactEmail",
        sorting: true,
        minWidth: 90,

      },
      {
        name: "AR_ContactName",
        displayName: "ContactName",
        sorting: true,
        minWidth: 90,
      },
      {
        name: "AR_ContactPhone",
        displayName: "ContactPhone",
        sorting: true,
        minWidth: 90,
      },
      {
        name: "AR_Introducer.Title",
        displayName: "Introducer",
        sorting: true,
        minWidth: 90,
      },

      {
        name: "AR_StartDate",
        displayName: "StartDate",
        minWidth: 90,

      },
      {
        name: "AR_VatNumber",
        displayName: "Vat number",
        minWidth: 100,
      },

    ];

    this.state = { items: [], viewFields: _viewFields };
    this._getfiles();
  }

  public render(): React.ReactElement<IGridviewProps> {

    return (

      <div className={styles.gridview}>
        <ListView
          items={this.state.items}
          viewFields={this.state.viewFields}
          // iconFieldName="ServerRelativeUrl"
          compact={true}
          // selectionMode={SelectionMode.multiple}
          // selection={this._getSelection}
          showFilter={true}
          filterPlaceHolder="Search..." />

      </div>
    );
  }


  public async _getfiles() {
    const allItems: any = await sp.web.lists.getByTitle("AR_Clients").items.select("AR_VatNumber", "AR_StartDate", "AR_Introducer/Title", "AR_Introducer/ID", "AR_ContactPhone", "AR_ContactName", "AR_ContactEmail", "AR_ClientName", "AR_ClientAddress", "AR_ClientStatus", "AR_CompanyNumber").expand("AR_Introducer").top(100).get();
    this.setState({ items: allItems });
  }

}


