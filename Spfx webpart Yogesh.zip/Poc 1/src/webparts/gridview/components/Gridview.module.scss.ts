/* tslint:disable */
require("./Gridview.module.css");
const styles = {
  gridview: 'gridview_372d3e61',
  container: 'container_372d3e61',
  row: 'row_372d3e61',
  ListView: 'ListView_372d3e61',
  column: 'column_372d3e61',
  'ms-Grid': 'ms-Grid_372d3e61',
  title: 'title_372d3e61',
  subTitle: 'subTitle_372d3e61',
  description: 'description_372d3e61',
  button: 'button_372d3e61',
  label: 'label_372d3e61'
};

export default styles;
/* tslint:enable */