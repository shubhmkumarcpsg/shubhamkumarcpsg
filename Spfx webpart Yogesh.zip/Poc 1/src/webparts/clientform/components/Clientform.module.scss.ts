/* tslint:disable */
require("./Clientform.module.css");
const styles = {
  spfxwebpart: 'spfxwebpart_57764ab8',
  container: 'container_57764ab8',
  row: 'row_57764ab8',
  column: 'column_57764ab8',
  'ms-Grid': 'ms-Grid_57764ab8',
  title: 'title_57764ab8',
  subTitle: 'subTitle_57764ab8',
  description: 'description_57764ab8',
  button: 'button_57764ab8',
  label: 'label_57764ab8'
};

export default styles;
/* tslint:enable */