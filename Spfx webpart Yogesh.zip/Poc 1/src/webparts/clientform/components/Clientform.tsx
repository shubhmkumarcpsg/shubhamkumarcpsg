import * as React from 'react';
import styles from './Clientform.module.scss';
import { IClientformProps } from './IClientformProps';
import { autobind, MessageBar, MessageBarType, IPersonaProps } from 'office-ui-fabric-react';
import { PrimaryButton, TextField, IStackProps, Label } from 'office-ui-fabric-react';
import { Dropdown, IDropdownOption, DropdownMenuItemType } from 'office-ui-fabric-react/lib/Dropdown';
import { DatePicker, DayOfWeek, IDatePickerStrings } from 'office-ui-fabric-react';
import { DateTimePicker, DateConvention, TimeConvention, TimeDisplayControlType } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import { IStackTokens, Stack } from 'office-ui-fabric-react/lib/Stack';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { sp } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { getGUID } from '@pnp/common';
import { IUserDetail } from './IClientformState';


const verticalStackProps: IStackProps = {
  styles: { root: { overflow: 'hidden', width: '100%' } },
  tokens: { childrenGap: 20 }
};

const ops = [
  { key: 'approved', text: 'approved' },
  { key: 'reject', text: 'reject' },
  { key: 'pending', text: 'pending' },

];
const DayPickerStrings: IDatePickerStrings = {
  months: [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ],

  shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],

  days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],

  shortDays: ['S', 'M', 'T', 'W', 'T', 'F', 'S'],

  goToToday: 'Go to today',
  prevMonthAriaLabel: 'Go to previous month',
  nextMonthAriaLabel: 'Go to next month',
  prevYearAriaLabel: 'Go to previous year',
  nextYearAriaLabel: 'Go to next year',
  closeButtonAriaLabel: 'Close date picker',
};



export default class Spfxwebpart extends React.Component<IClientformProps, any> {

  constructor(props: IClientformProps, state: any) {
    super(props);
    this.state = {

      CreateNewDocumentForm: {},
      // date: new Date(),
      Items: {},
      endDate: new Date(),
      _onChangeDropdown: {},
      errors: {},

      showMessageBar: false
    };
  }
  public render(): React.ReactElement<IClientformProps> {

    return (

      <div style={{ backgroundColor: "antiquewhite" }} className={styles.row}>
        {
          this.state.showMessageBar
            ?
            <div className="form-group">
              <Stack {...verticalStackProps}>
                <MessageBar messageBarType={this.state.messageType}>{this.state.message}</MessageBar>
              </Stack>
            </div>
            :
            null
        }
        <div className={styles.row}>
          <div className="form-group">
            <Label>NEW CLIENT</Label>

            <div ><TextField className="design" label="ClientName" id="ClientName"  onChange={this._inputUpdate}
            /> <div className="ErrorMessage" style={{ color: "red" }}> {this.state.errors.ClientName}</div></div>

            <div><TextField className="design" label="ContactEmail" type="email" id="ContactEmail" onChange={this._inputUpdate}
            /> <div className="ErrorMessage" style={{ color: "red" }} > {this.state.errors.ContactEmail}</div></div>

            <div><TextField className="design" label="ClientAddress" id="ClientAddress" onChange={this._inputUpdate}
            /> <div className="ErrorMessage" style={{ color: "red" }}> {this.state.errors.ClientAddress}</div></div>

            <div><TextField className="design" label="ContactName" id="ContactName" onChange={this._inputUpdate}
            /> <div className="ErrorMessage" style={{ color: "red" }}> {this.state.errors.ContactName}</div></div>

            <div><TextField className="design" label="ContactPhoneNumber" id="ContactPhoneNumber" min="10" max="10" onChange={this._inputUpdate}
            /> <div className="ErrorMessage" style={{ color: "red" }}> {this.state.errors.ContactPhoneNumber}</div></div>

            <div><TextField className="design" label="CompanyNumber" id="CompanyNumber" onChange={this._inputUpdate}
            /> <div className="ErrorMessage" style={{ color: "red" }}> {this.state.errors.CompanyNumber}</div></div>

            <div><TextField className="design" label="VatNumber" id="VatNumber" onChange={this._inputUpdate}
            /> <div className="ErrorMessage" style={{ color: "red" }}> {this.state.errors.VatNumber}</div></div>

            <div >

              <DateTimePicker label="End Date"
                dateConvention={DateConvention.Date}
                timeConvention={TimeConvention.Hours12}
                timeDisplayControlType={TimeDisplayControlType.Dropdown}
                showLabels={false}
                value={this.state.endDate}

                onChange={this.__onchangedEndDate} />
            </div>

            <div>
              <Dropdown
                placeholder="Select company code"
                label="ClientStatus"
                id="AR_ClientStatus"
                // disabled={this.state.documentID != 0}
                selectedKey={this.state.CreateNewDocumentForm.AR_ClientStatus ? this.state.CreateNewDocumentForm.AR_ClientStatus.key : undefined}
                defaultSelectedKey={this.state.CreateNewDocumentForm.AR_ClientStatus}
                options={ops}

                onChange={this._onChangeDropdown} />
            </div>

            <div>
              <PeoplePicker
                context={this.props.context}
                titleText="Introducer"
                personSelectionLimit={1}
                groupName={""} // Leave this blank in case you want to filter from all users    
                showtooltip={true}
                isRequired={true}
                disabled={false}
                ensureUser={true}
                selectedItems={this._getPeoplePickerItems}
                showHiddenInUI={false}
                principalTypes={[PrincipalType.User]}
                resolveDelay={1000} />
            </div>


          </div>

        </div><br></br>
        <PrimaryButton text="Submit" allowDisabledFocus disabled={false} onClick={() => { this._checkValidation(); }} />
      </div>

    );
  }

  public _checkValidation(): any {
    var IsReturn = true;
    var errors = {};

    //Title
    var patternTt = new RegExp(/^[a-zA-Z ]*$/);
    if (!patternTt.test(this.state.ClientName) || this.state.CreateNewDocumentForm.ClientName == null || this.state.CreateNewDocumentForm.ClientName == undefined || this.state.CreateNewDocumentForm.ClientName == "") {
      IsReturn = false;
      errors = this.state.errors.ClientName = "ClientName is required*";
    }

    //Client Address
    if (this.state.CreateNewDocumentForm.ClientAddress == null ||
      this.state.CreateNewDocumentForm.ClientAddress == undefined ||
      this.state.CreateNewDocumentForm.ClientAddress == "") {
      IsReturn = false;
      errors = this.state.errors.ClientAddress = "ClientAddress is required*";
    }

    //Contact name
    // var patternT = new RegExp(/^[a-zA-Z ]*$/);
    // if (!patternT.test(this.state.CreateNewDocumentForm.ContactName) || this.state.CreateNewDocumentForm.ContactName == null || this.state.CreateNewDocumentForm.ContactName == undefined || this.state.CreateNewDocumentForm.Title == "") {
    //   IsReturn = false;
    //   errors = this.state.errors.ContactName = "ContactName is required*";
    // }

    //Contact phone number  
    var patternCPN = new RegExp(/^[0-9\b]+$/);
    if (!patternCPN.test(this.state.CreateNewDocumentForm.ContactPhoneNumber) || this.state.CreateNewDocumentForm.ContactPhoneNumber == null || this.state.CreateNewDocumentForm.ContactPhoneNumber == undefined || this.state.CreateNewDocumentForm.ContactPhoneNumber == "") {
      IsReturn = false;
      errors = this.state.errors.ContactPhoneNumber = "ContactPhoneNumber is required*";
    } else if (this.state.CreateNewDocumentForm.ContactPhoneNumber.length != 10) {

      IsReturn = false;
      errors = this.state.errors.ContactPhoneNumber = "enter valid ContactPhoneNumber*";
    }

    //Contact email
    var patternCE = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    if
      (!patternCE.test(this.state.CreateNewDocumentForm.ContactEmail) || this.state.CreateNewDocumentForm.ContactEmail == null || this.state.CreateNewDocumentForm.ContactEmail == undefined || this.state.CreateNewDocumentForm.ContactEmail == "") {
      IsReturn = false;
      errors = this.state.errors.ContactEmail = "enter valid email*";
    }

    //company number
    // var patternCN = new RegExp(/^[0-9\b]+$/);
    // if (!patternCN.test(this.state.CreateNewDocumentForm.CompanyNumber) || this.state.CreateNewDocumentForm.CompanyNumber == null || this.state.CreateNewDocumentForm.CompanyNumber == undefined || this.state.CreateNewDocumentForm.CompanyNumber == "") {
    //   IsReturn = false;
    //   errors = this.state.errors.CompanyNumber = "CompanyNumber is required*";
    // } else if (this.state.CreateNewDocumentForm.CompanyNumber.length != 10) {

    //   IsReturn = false;
    //   errors = this.state.errors.CompanyNumber = "enter valid CompanyNumber";
    // }

    // //vat number
    // var patternVN = new RegExp(/^[0-9\b]+$/);
    // if (!patternVN.test(this.state.CreateNewDocumentForm.VatNumber) || this.state.CreateNewDocumentForm.VatNumber == null || this.state.CreateNewDocumentForm.VatNumber == undefined || this.state.CreateNewDocumentForm.VatNumber == "") {
    //   IsReturn = false;
    //   errors = this.state.errors.VatNumber = "VatNumber is required*";
    // } else if (this.state.CreateNewDocumentForm.VatNumber.length != 15) {

    //   IsReturn = false;
    //   errors = this.state.errors.VatNumber = "enter valid VatNumber";
    // }

    if (IsReturn == true) {
      this.createItem();
    } else {
      this.setState({
        errors: this.state.errors
      });
    }

  }

  private _onChangeDropdown = (event: React.FormEvent<HTMLDivElement>, item: IDropdownOption): void => {
    var CreateNewDocumentForm = this.state.CreateNewDocumentForm;
    CreateNewDocumentForm[event.target["id"]] = item;
    this.setState({ CreateNewDocumentForm: CreateNewDocumentForm });

  }

  @autobind
  private __onchangedEndDate(date: any): void {
    this.setState({ endDate: date });
  }

  @autobind
  private _getPeoplePickerItems(items: any[]) {
    let userarr: IUserDetail[] = [];
    items.forEach(user => {
      userarr.push({ Id: user.id });
    });
    this.setState({ UserDetails: userarr[0] });

  }

  private _inputUpdate = e => {
    var createNewDocumentForm = this.state.CreateNewDocumentForm;
    createNewDocumentForm[e.target.id] = e.target.value,
      this.setState({
        MyForm: createNewDocumentForm
      });
  }


  @autobind
  private async createItem() {

    try {
      await sp.web.lists.getByTitle('Poc').items.add({
        Title: this.state.CreateNewDocumentForm.ClientName,
        // AR_ClientAddress: this.state.CreateNewDocumentForm.ClientAddress,
        // AR_ContactName: this.state.CreateNewDocumentForm.ContactName,
        // AR_ContactPhone: this.state.CreateNewDocumentForm.ContactPhoneNumber,
        // AR_ContactEmail: this.state.CreateNewDocumentForm.ContactEmail,
        // AR_CompanyNumber: this.state.CreateNewDocumentForm.CompanyNumber,
        // AR_VatNumber: this.state.CreateNewDocumentForm.VatNumber,
        // AR_StartDate: this.state.endDate,
        EMPNameId: this.state.UserDetails.Id,
        // AR_ClientStatus: this.state.CreateNewDocumentForm.AR_ClientStatus.key
       

      });
      this.setState({
        message: "Item:  - created successfully!",
        showMessageBar: true,
        messageType: MessageBarType.success
      });
    }
    catch (error) {
      this.setState({
        message: "Item  creation failed with error: " + error,
        showMessageBar: true,
        messageType: MessageBarType.error
      });
    }
  }
}
