import { MessageBarType } from 'office-ui-fabric-react';  
import { WebPartContext } from '@microsoft/sp-webpart-base';
  
export interface IClientformState {  
    title: string;
    ClientAddress:string;
    context: WebPartContext;  
    UserDetails: IUserDetail[];
    selectedusers: string[];
    showMessageBar: boolean;    
    messageType?: MessageBarType;    
    message?: string;  
    ContactEmail:null;
    
}

export interface IUserDetail{
Id: string; 
}