import { IViewField } from "@pnp/spfx-controls-react/lib/ListView";
 
export interface IMattergridviewState {
  items: any[];
  viewFields: IViewField[];
  addText: string;
  updateText:IListItem[];

}

export interface IListItem {
   // ID: number;
   
    AR_MatterNumber(AR_MatterNumber: any);
    Id: number;
    title: string;
  }