import * as React from 'react';
import styles from './Mattergridview.module.scss';
import { IMattergridviewProps } from './IMattergridviewProps';
import { IMattergridviewState, IListItem } from './IMattergridviewState';
import { ListView, IViewField, SelectionMode } from "@pnp/spfx-controls-react/lib/ListView";
import { escape } from '@microsoft/sp-lodash-subset';
import { FieldUrlRenderer } from "@pnp/spfx-controls-react/lib/FieldUrlRenderer";
import { sp } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { PrimaryButton, autobind, Button } from 'office-ui-fabric-react';

 

export default class Mattergridview extends React.Component<IMattergridviewProps, any> {

  constructor(props: IMattergridviewProps, state: any) {
    super(props);
    this.state = {
      items: {},
      updateText: [],
     
    };

    const _viewFields: IViewField[] = [
      {
        name: "AR_MatterNumber",
        displayName: "MatterNumber",
        sorting: true,
        minWidth: 90,

      },
      {
        name: "AR_ClientName.AR_ClientName",
        displayName: "ClientName",
        sorting: true,
        minWidth: 90,

      },

      {
        name: "AR_MatterName",
        displayName: "MatterName",
        minWidth: 90,
        sorting: true,
        
      },
      {
        name: "AR_AriaOfLaw",
        displayName: "AriaOfLaw",
        sorting: true,
        minWidth: 100,
      },

      {
        name: "AR_LawyerAssign.Title",
        displayName: "AssignedLawyer",
        sorting: true,
        minWidth: 90,

      },
      {
        name: "AR_MatterStatus",
        displayName: "Matterstatus",
        sorting: true,
        minWidth: 90,
      },
   
      {
        name: "Delete",
        displayName: "Delete Matter",
        sorting: true,
        minWidth: 90,
        render: (item: any) => {
          
          return( 
          
          <PrimaryButton text="delete" allowDisabledFocus onClick={()=> {this._deleteClicked(item);}}/>
        
          );
          }
          
      },
      {
        name: "Edit",
        displayName: "Edit Matter",
        sorting: true,
        minWidth: 90,
        render: (item: any) => {
          
          return( 
          
          <PrimaryButton text="edit" allowDisabledFocus onClick={()=> {this._editform(item);}}/>
          
          );
          }
          
      },
    ];

    this.state = { items: [], viewFields: _viewFields };
    this._getfiles();
    this._queryurl();
  }

  public render(): React.ReactElement<IMattergridviewProps> {

    return (
      
      <div className={styles.mattergridview}>
        <ListView
          items={this.state.items}
          viewFields={this.state.viewFields}
           iconFieldName="ServerRelativeUrl"
          compact={true}
          // selectionMode={SelectionMode.multiple}
          // selection={this._getSelection}
          
          showFilter={true}
          filterPlaceHolder="Search..." />

      </div>
    );
  }


  @autobind
  public async _queryurl(){
    var qurl = window.location.href.split('?')[1].split('=')[1].toString() ;
    
  } 
  
  @autobind
    public async _editform(item: IListItem) {
   // this._getfiles(); 
   //const editItem = sp.web.lists.getByTitle("AR_Matter").items.getById(item.Id).update;
   var frmurl = this.props.context.pageContext.web.absoluteUrl +"?matterid="+item.Id ;
   
   window.location.href = frmurl ;
   //this._updateClicked(item);
   }

  @autobind
  public async _deleteClicked(item: IListItem) {
   // this._getfiles(); 
    const deletedItem = await sp.web.lists.getByTitle("AR_Matter").items.getById(item.Id).recycle();
   }


  public async _getfiles() {
    const allItems: any = await sp.web.lists.getByTitle("AR_Matter").items.select("ID","AR_MatterNumber", "AR_ClientName/ID","AR_ClientName/AR_ClientName","AR_MatterName", "AR_LawyerAssign/ID","AR_LawyerAssign/Title", "AR_AriaOfLaw", "AR_LawyerAssign", "AR_MatterStatus").expand("AR_LawyerAssign","AR_ClientName").top(100).get();
    this.setState({ items: allItems });
//    console.log(allItems);
  }

}


