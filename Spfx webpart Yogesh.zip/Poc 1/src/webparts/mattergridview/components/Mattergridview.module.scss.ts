/* tslint:disable */
require("./Mattergridview.module.css");
const styles = {
  mattergridview: 'mattergridview_e9c8e632',
  container: 'container_e9c8e632',
  row: 'row_e9c8e632',
  column: 'column_e9c8e632',
  'ms-Grid': 'ms-Grid_e9c8e632',
  title: 'title_e9c8e632',
  subTitle: 'subTitle_e9c8e632',
  description: 'description_e9c8e632',
  button: 'button_e9c8e632',
  label: 'label_e9c8e632'
};

export default styles;
/* tslint:enable */