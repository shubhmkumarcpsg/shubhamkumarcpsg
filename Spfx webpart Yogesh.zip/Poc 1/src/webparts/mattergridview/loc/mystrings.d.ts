declare interface IMattergridviewWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MattergridviewWebPartStrings' {
  const strings: IMattergridviewWebPartStrings;
  export = strings;
}
