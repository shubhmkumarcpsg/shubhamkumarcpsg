import * as React from 'react';
import { IMattergridviewProps } from './IMattergridviewProps';
import { IListItem } from './IMattergridviewState';
import "@pnp/sp/webs";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
export default class Mattergridview extends React.Component<IMattergridviewProps, any> {
    constructor(props: IMattergridviewProps, state: any);
    render(): React.ReactElement<IMattergridviewProps>;
    _queryurl(): Promise<void>;
    _editform(item: IListItem): Promise<void>;
    _deleteClicked(item: IListItem): Promise<void>;
    _getfiles(): Promise<void>;
}
//# sourceMappingURL=Mattergridview.d.ts.map