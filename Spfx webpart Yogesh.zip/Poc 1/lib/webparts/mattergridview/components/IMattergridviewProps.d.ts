import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IMattergridviewProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IMattergridviewProps.d.ts.map