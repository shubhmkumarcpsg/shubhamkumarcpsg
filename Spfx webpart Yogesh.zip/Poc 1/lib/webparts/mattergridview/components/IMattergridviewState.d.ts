import { IViewField } from "@pnp/spfx-controls-react/lib/ListView";
export interface IMattergridviewState {
    items: any[];
    viewFields: IViewField[];
    addText: string;
    updateText: IListItem[];
}
export interface IListItem {
    AR_MatterNumber(AR_MatterNumber: any): any;
    Id: number;
    title: string;
}
//# sourceMappingURL=IMattergridviewState.d.ts.map