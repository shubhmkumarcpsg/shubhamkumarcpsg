import { MessageBarType } from 'office-ui-fabric-react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
export interface IMattersformState {
    context: WebPartContext;
    UserDetails: IUserDetail[];
    showMessageBar: boolean;
    messageType?: MessageBarType;
    message?: string;
    projectlookupvalues: IDropdownOption[];
    salestitle: string;
    seletedprojects: number[];
    items: IItemId[];
}
export interface IUserDetail {
    Id: string;
}
export interface IItemId {
    ID: number;
}
//# sourceMappingURL=IMatterformState.d.ts.map