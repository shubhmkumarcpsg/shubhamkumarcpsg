export interface IMatterformProps {
    description: string;
    context: any;
}
//# sourceMappingURL=IMatterformProps.d.ts.map