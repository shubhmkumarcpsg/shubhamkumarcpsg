import * as React from 'react';
import { IMatterformProps } from './IMatterformProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { IListItem } from '../../mattergridview/components/IMattergridviewState';
export default class Matterform extends React.Component<IMatterformProps, any> {
    constructor(props: IMatterformProps, state: any);
    render(): React.ReactElement<IMatterformProps>;
    _queryurl(): Promise<void>;
    _btnclick(item: any): Promise<void>;
    _updateClicked(item: IListItem): Promise<void>;
    _getId(): Promise<void>;
    private _getLookupvalues;
    private _getPeoplePickerItems;
    private _onChangeDropdown;
    private _inputUpdate;
    private createItem;
}
//# sourceMappingURL=Matterform.d.ts.map