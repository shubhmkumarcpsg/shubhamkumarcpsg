export interface IClientformProps {
    listName: string;
    context: any;
}
//# sourceMappingURL=IClientformProps.d.ts.map