import * as React from 'react';
import { IClientformProps } from './IClientformProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
export default class Spfxwebpart extends React.Component<IClientformProps, any> {
    constructor(props: IClientformProps, state: any);
    render(): React.ReactElement<IClientformProps>;
    _checkValidation(): any;
    private _onChangeDropdown;
    private __onchangedEndDate;
    private _getPeoplePickerItems;
    private _inputUpdate;
    private createItem;
}
//# sourceMappingURL=Clientform.d.ts.map