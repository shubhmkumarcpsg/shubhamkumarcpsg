import * as React from 'react';
import { IGridviewProps } from './IGridviewProps';
import "@pnp/sp/webs";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
export default class Gridview extends React.Component<IGridviewProps, any> {
    constructor(props: IGridviewProps, state: any);
    render(): React.ReactElement<IGridviewProps>;
    _getfiles(): Promise<void>;
}
//# sourceMappingURL=Gridview.d.ts.map