export interface IGridviewProps {
    description: string;
    context: any;
}
//# sourceMappingURL=IGridviewProps.d.ts.map