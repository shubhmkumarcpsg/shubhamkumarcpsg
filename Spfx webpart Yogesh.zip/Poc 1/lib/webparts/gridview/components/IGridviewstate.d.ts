import { IViewField } from "@pnp/spfx-controls-react/lib/ListView";
export interface IGridviewstate {
    items: any[];
    viewFields: IViewField[];
}
//# sourceMappingURL=IGridviewstate.d.ts.map