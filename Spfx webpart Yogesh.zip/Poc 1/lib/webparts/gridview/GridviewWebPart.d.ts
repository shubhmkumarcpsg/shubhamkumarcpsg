import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IGridviewWebPartProps {
    description: string;
}
export default class GridviewWebPart extends BaseClientSideWebPart<IGridviewWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=GridviewWebPart.d.ts.map