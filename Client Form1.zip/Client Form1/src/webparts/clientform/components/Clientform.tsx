import * as React from 'react';
import styles from './Clientform.module.scss';
import { IClientformProps } from './IClientformProps';
import { autobind, MessageBar, MessageBarType, IPersonaProps } from 'office-ui-fabric-react';
import { PrimaryButton, TextField,  Label } from 'office-ui-fabric-react';
import { Dropdown, IDropdownOption, DropdownMenuItemType } from 'office-ui-fabric-react/lib/Dropdown';
import { DatePicker, DayOfWeek, IDatePickerStrings } from 'office-ui-fabric-react';
import { DateTimePicker, DateConvention, TimeConvention, TimeDisplayControlType } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { IUserDetail } from './IClientformState';
import { ISPHttpClientOptions, SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';



export default class Spfxwebpart extends React.Component<IClientformProps, any> {

  constructor(props: IClientformProps, state: any) {
    super(props);
    this.state = {

      CreateNewDocumentForm: {},
      // date: new Date(),
      Items: {},
      endDate: new Date(),
      _onChangeDropdown: {},
      errors: {},

      showMessageBar: false
    };

  }
  // componentDidMount(){
  //   this._inputUpdate=this._inputUpdate.bind(this);

  // }
  public render(): React.ReactElement<IClientformProps> {

    return (

      <div style={{ backgroundColor: "antiquewhite" }} className={styles.row}>
     
        <div className={styles.row}>
          <div className="form-group">
            <Label>NEW CLIENT</Label>

            <div className="design">
                        <label className="design">Employee Name</label>
         <input className="design" name="empname" id="empname" onChange={this._inputUpdate}
                        type="text" placeholder="Employee Name" />
                        
                       
                      </div>
           

            <div >

              <DateTimePicker label="End Date"
                dateConvention={DateConvention.Date}
                timeConvention={TimeConvention.Hours12}
                timeDisplayControlType={TimeDisplayControlType.Dropdown}
                showLabels={false}
                value={this.state.endDate}

                onChange={this.__onchangedEndDate} />
            </div>

           

            <div>
              <PeoplePicker
                context={this.props.context}
                titleText="Introducer"
                personSelectionLimit={1}
                groupName={""} // Leave this blank in case you want to filter from all users    
                showtooltip={true}
                isRequired={true}
                disabled={false}
                ensureUser={true}
                selectedItems={this._getPeoplePickerItems}
                showHiddenInUI={false}
                principalTypes={[PrincipalType.User]}
                resolveDelay={1000} />
            </div>


          </div>

        </div><br></br>
        <PrimaryButton text="Submit" onClick={() => { this.createItem(); }} />
      </div>

    );
  }

  


  @autobind
  private __onchangedEndDate(date: any): void {
    this.setState({ endDate: date });
  }

  @autobind
  private _getPeoplePickerItems(items: any[]) {
    let userarr: IUserDetail[] = [];
    items.forEach(user => {
      userarr.push({ Id: user.id });
    });
    this.setState({ UserDetails: userarr[0] });

  }

  private _inputUpdate = e => {
    var createNewDocumentForm = this.state.CreateNewDocumentForm;
    createNewDocumentForm[e.target.id] = e.target.value,
      this.setState({
        CreateNewDocumentForm: createNewDocumentForm
      });
  }

  public createItem(): void {  
    debugger;
        const url: string = this.props.context.pageContext.web.absoluteUrl + "/_api/web/lists/getbytitle('Category')/items";          
           
           const spHttpClientOptions: ISPHttpClientOptions = {
          "body": JSON.stringify({  
               Title: this.state.CreateNewDocumentForm.empname,
               EMPNameId: this.state.UserDetails.Id
            }) 
        };
    
        this.props.context.spHttpClient.post(url, SPHttpClient.configurations.v1, spHttpClientOptions)
        .then((response: SPHttpClientResponse) => {
         
          if (response.status === 201) {
            this.setState("Record added and All Records were loaded Successfully");         
    
           
           
          } else {
            let errormessage: string = "An error has occured i.e.  " + response.status + " - " + response.statusText;
            this.setState({status: errormessage});        
          }
        });
      }
    
    }