/* tslint:disable */
require('./Clientform.module.css');
const styles = {
  spfxwebpart: 'spfxwebpart_e8c0e889',
  container: 'container_e8c0e889',
  row: 'row_e8c0e889',
  column: 'column_e8c0e889',
  'ms-Grid': 'ms-Grid_e8c0e889',
  title: 'title_e8c0e889',
  subTitle: 'subTitle_e8c0e889',
  description: 'description_e8c0e889',
  button: 'button_e8c0e889',
  label: 'label_e8c0e889',
};

export default styles;
/* tslint:enable */