declare interface IClientformWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ClientformWebPartStrings' {
  const strings: IClientformWebPartStrings;
  export = strings;
}
