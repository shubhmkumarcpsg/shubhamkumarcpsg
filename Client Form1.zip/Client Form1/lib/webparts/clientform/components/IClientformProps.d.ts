export interface IClientformProps {
    listName: string;
    context: any;
}
