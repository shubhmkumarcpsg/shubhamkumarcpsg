/// <reference types="react" />
import * as React from 'react';
import { IClientformProps } from './IClientformProps';
export default class Spfxwebpart extends React.Component<IClientformProps, any> {
    constructor(props: IClientformProps, state: any);
    render(): React.ReactElement<IClientformProps>;
    private __onchangedEndDate(date);
    private _getPeoplePickerItems(items);
    private _inputUpdate;
    createItem(): void;
}
