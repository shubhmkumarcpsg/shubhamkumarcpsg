import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IClientformWebPartProps {
    listName: string;
    selectedValues: any[];
    endDate: Date;
    selectedOption?: string;
    useState: any;
    ContactEmail: null;
}
export default class ClientformWebPart extends BaseClientSideWebPart<IClientformWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
