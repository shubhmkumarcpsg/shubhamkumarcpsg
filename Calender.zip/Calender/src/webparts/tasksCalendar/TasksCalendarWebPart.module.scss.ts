/* tslint:disable */
require('./TasksCalendarWebPart.module.css');
const styles = {
  tasksCalendar: 'tasksCalendar_9574306f',
  container: 'container_9574306f',
  row: 'row_9574306f',
  column: 'column_9574306f',
  'ms-Grid': 'ms-Grid_9574306f',
  title: 'title_9574306f',
  subTitle: 'subTitle_9574306f',
  description: 'description_9574306f',
  button: 'button_9574306f',
  label: 'label_9574306f',
};

export default styles;
/* tslint:enable */