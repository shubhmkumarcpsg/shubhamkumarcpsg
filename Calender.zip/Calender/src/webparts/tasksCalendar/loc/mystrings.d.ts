declare interface ITasksCalendarWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'TasksCalendarWebPartStrings' {
  const strings: ITasksCalendarWebPartStrings;
  export = strings;
}
