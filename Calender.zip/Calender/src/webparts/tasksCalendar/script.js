var moment = require('moment');

//var PATH_TO_DISPFORM = window.webAbsoluteUrl + "/Lists/Emp/AllItems.aspx";
//https://mohitcpsg.sharepoint.com/sites/Elearning/Lists/Emp/DispForm.aspx
var PATH_TO_DISPFORM = window.webAbsoluteUrl + "/Lists/Emp/DispForm.aspx";
var TASK_LIST = "Emp";


DisplayTasks();

function GetColor(category) {
    let color = '';
    
    switch (category) {
        case "Meeting":
            color = "#c00000";
            break;
        case "Work hours":
            color = "#466365";
            break;
        case "Birthday":
            color = "#B49A67";
            break;
        default:
            color = '#000';
            break;
    }
    return color;
}

function DisplayTasks() {
    $('#calendar').fullCalendar('destroy');
    $('#calendar').fullCalendar({

        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,basicWeek,basicDay'
        },

        defaultView: "month",
        navLinks: true, // can click day/week names to navigate views
        selectable: true,
        selectHelper: false,
        editable: true,

        select: function(start, end, jsEvent, view,calEvent){
            //wrtie your redirection code here
            alert("hello");
          },
        
       
        //open up the display form when a user clicks on an event
        eventClick: function (calEvent, jsEvent, view) {
      window.location = PATH_TO_DISPFORM + "?ID=" + calEvent.id;
        },

       
        timezone: "UTC",
        droppable: true, // this allows things to be dropped onto the calendar
        //update the end date when a user drags and drops an event 
        eventDrop: function (event, delta, revertFunc) {
            UpdateTask(event.id, event.end);
        },
        //put the events on the calendar 
        events: function (start, end, timezone, callback) {
            startDate = start.format('YYYY-MM-DD');
            endDate = end.format('YYYY-MM-DD');

            var RESTQuery = "/_api/Web/Lists/GetByTitle('" + TASK_LIST + "')/items?$select=ID,Title,\
          Category,EventDate,EndDate,AssignedTo/Title&$expand=AssignedTo";

            var opencall = $.ajax({
                url: window.webAbsoluteUrl + RESTQuery,
                type: "GET",
                dataType: "json",
                headers: {
                    Accept: "application/json;odata=verbose"
                }
            });

            opencall.done(function (data, textStatus, jqXHR) {
                var result = data.d.results;
                debugger;
                var events = [];
                if(result.length > 0){
                    events = result.map((item) => {
                        
                        return (
                            {
                                title: item.Title + ' - ' + item.AssignedTo.Title,
                                id: item.ID,
                                color: GetColor(item.Category),
                                start: moment.utc(item.EventDate),
                                end: moment.utc(item.EndDate)
                            }
                        )
                    });
                }
              
               

                callback(events);

            });
        }



        
    });
}




function UpdateTask(id, EndDate) {

    sDate = moment.utc(dueDate).add("-1", "days").format('YYYY-MM-DD') + "T" +
        dueDate.format("hh:mm") + ":00Z";

    var call = jQuery.ajax({
        url: window.webAbsoluteUrl +
            "/_api/Web/Lists/getByTitle('" + TASK_LIST + "')/Items(" + id + ")",
        type: "POST",
        data: JSON.stringify({
            EndDate: sDate,
        }),
        headers: {
            Accept: "application/json;odata=nometadata",
            "Content-Type": "application/json;odata=nometadata",
            "X-RequestDigest": jQuery("#__REQUESTDIGEST").val(),
            "IF-MATCH": "*",
            "X-Http-Method": "PATCH"
        }
    });
    call.done(function (data, textStatus, jqXHR) {
        alert("Update Successful");
        DisplayTasks();
    });
    call.fail(function (jqXHR, textStatus, errorThrown) {
        alert("Update Failed");
        DisplayTasks();
    });

}
