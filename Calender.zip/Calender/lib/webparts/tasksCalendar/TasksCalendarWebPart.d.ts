import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import 'jquery';
import 'moment';
import 'fullcalendar';
export interface ITasksCalendarWebPartProps {
    description: string;
}
export default class TasksCalendarWebPart extends BaseClientSideWebPart<ITasksCalendarWebPartProps> {
    render(): void;
}
