import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import 'jquery';
import 'moment';
import 'fullcalendar';
export interface ICalenderWebPartProps {
    description: string;
}
export default class CalenderWebPart extends BaseClientSideWebPart<ICalenderWebPartProps> {
    render(): void;
}
