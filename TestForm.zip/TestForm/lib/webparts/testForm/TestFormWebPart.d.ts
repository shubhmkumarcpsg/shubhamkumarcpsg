import { BaseClientSideWebPart, IPropertyPaneConfiguration, WebPartContext } from '@microsoft/sp-webpart-base';
export interface ITestFormWebPartProps {
    description: string;
    context: WebPartContext;
}
export default class TestFormWebPart extends BaseClientSideWebPart<ITestFormWebPartProps> {
    render(): void;
    private AddEventListeners();
    EditForm(): any;
    private SubmitData();
    private GetUserId(userName);
    private _getCategoryData();
    private getCategoryData();
    private _renderCategoryList(items);
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
