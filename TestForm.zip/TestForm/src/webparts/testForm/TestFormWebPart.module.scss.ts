/* tslint:disable */
require('./TestFormWebPart.module.css');
const styles = {
  testForm: 'testForm_0847ba6e',
  container: 'container_0847ba6e',
  row: 'row_0847ba6e',
  column: 'column_0847ba6e',
  'ms-Grid': 'ms-Grid_0847ba6e',
  title: 'title_0847ba6e',
  subTitle: 'subTitle_0847ba6e',
  description: 'description_0847ba6e',
  button: 'button_0847ba6e',
  label: 'label_0847ba6e',
};

export default styles;
/* tslint:enable */