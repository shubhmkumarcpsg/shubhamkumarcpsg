declare interface ITestFormWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'TestFormWebPartStrings' {
  const strings: ITestFormWebPartStrings;
  export = strings;
}
