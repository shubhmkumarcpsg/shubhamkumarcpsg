import { UrlQueryParameterCollection, Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, 
   IPropertyPaneConfiguration,
  PropertyPaneTextField,
  WebPartContext} from '@microsoft/sp-webpart-base';

 
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './TestFormWebPart.module.scss';
import * as strings from 'TestFormWebPartStrings';

import { SPComponentLoader } from '@microsoft/sp-loader';
import pnp, { sp, Item, ItemAddResult, ItemUpdateResult, Web } from 'sp-pnp-js';

import * as $ from 'jquery';
require('jquery');
require('bootstrap');
require('./css/jquery-ui.css');
let cssURL = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css";
SPComponentLoader.loadCss(cssURL);
SPComponentLoader.loadScript("https://ajax.aspnetcdn.com/ajax/4.0/1/MicrosoftAjax.js");
require('appjs');
require('sppeoplepicker');
require('jqueryui');




export interface ITestFormWebPartProps {
  description: string;
  context:WebPartContext;
}

export default class TestFormWebPart extends BaseClientSideWebPart<ITestFormWebPartProps> {
  

  public render(): void {
    this.domElement.innerHTML = `
    <div id="container">
     
    <div class="panel">
      <div class="panel-body">
        <div class="row">
          <div class="col-lg-4 control-padding">
            <label>Location</label>
            <input type='textbox' name='txtActivity' id='txtActivity' class="form-control" value="" placeholder="" >
          </div>
          <div class="col-lg-4 control-padding">
            <label>Assign To</label>
           
              <div id="ppDefault"></div>
          </div>
          <div class="col-lg-4 control-padding">
            <label>DateTo</label>
            <div class="input-group date" data-provide="datepicker">
      <input type="text" class="form-control" id="Dateto" name="txtDate">
  </div>
          </div>          
        </div>
        <div class="col-lg-4 control-padding">
        <label>DateFrom</label>
        <div class="input-group date" data-provide="datepicker">
  <input type="text" class="form-control" id="Datefrom" name="txtDate">
</div>
      </div>  
      <div class="row">
    <div class="col-lg-6 control-padding">
        <label>Category</label>
        <select name="ddlCategory" id="ddlCategory" class="form-control">

        </select>
      </div>
      </div>        
    </div>
    
               
  
        <div class="row">
        <div class="col col-lg-12">
        <button type="button" class="btn btn-primary buttons" id="btnSubmit">Save</button>
			  <button type="button" class="btn btn-default buttons" id="btnEdit">Edit</button>
      </div>
        </div>
  
      </div>
    </div>`;

    (<any>$("#Dateto")).datepicker(
      {
        changeMonth: true,
        changeYear: true,
        dateFormat: "mm/dd/yy"
      }
    );
    (<any>$("#Datefrom")).datepicker(
      {
        changeMonth: true,
        changeYear: true,
        dateFormat: "mm/dd/yy"
      }
    );
    (<any>$('#ppDefault')).spPeoplePicker({
      minSearchTriggerLength: 2,
      maximumEntitySuggestions: 10,
      principalType: 1,
      principalSource: 15,
      searchPrefix: '',
      searchSuffix: '',
      displayResultCount: 6,
      maxSelectedUsers: 1
    });
    this.AddEventListeners();
   this.getCategoryData();
  }

  private AddEventListeners(): any {
    document.getElementById('btnSubmit').addEventListener('click', () => this.SubmitData());
    document.getElementById('btnEdit').addEventListener('click', () => this.EditForm());   
  
  }
  EditForm(): any {
    throw new Error('Method not implemented.');
  }

private SubmitData(){
  var userinfo = (<any>$('#ppDefault')).spPeoplePicker('get');
  var userId;
  var userDetails = this.GetUserId(userinfo[0].email.toString());
  console.log(JSON.stringify(userDetails));
  userId = userDetails.d.Id;

  pnp.sp.web.lists.getByTitle('Emp').items.add({
    Title: $("#ddlCategory").val().toString(),
    Location: $("#txtActivity").val().toString(),
    EventDate: $("#Dateto").val().toString(),
    EndDate: $("#Datefrom").val().toString(),
    AssignedToId : userId,
    Category: $("#ddlCategory").val().toString(),
    
});
}

private GetUserId(userName) {
  var siteUrl = this.context.pageContext.web.absoluteUrl;

  var call = $.ajax({
    url: siteUrl + "/_api/web/siteusers/getbyloginname(@v)?@v=%27i:0%23.f|membership|" + userName + "%27",
    method: "GET",
    headers: { "Accept": "application/json; odata=verbose" },
    async: false,
    dataType: 'json'
  }).responseJSON;
  return call;
}

 

private _getCategoryData(): any {    
  return pnp.sp.web.lists.getByTitle("Category").items.select("Title").getAll().then((response) => {
    return response;
  });
}

private getCategoryData(): any {
  this._getCategoryData()
    .then((response) => {
      this._renderCategoryList(response);
    });
}

private _renderCategoryList(items: any): void {

  let html: string = '';
  html += `<option value="Select Category" selected>Select Category</option>`;
  items.forEach((item: any) => {
    html += `
     <option value="${item.Title}">${item.Title}</option>`;
  });
  const listContainer1: Element = this.domElement.querySelector('#ddlCategory');
  listContainer1.innerHTML = html;
}
  

 


  

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
