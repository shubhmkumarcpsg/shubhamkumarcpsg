/* tslint:disable */
require('./CalenderWebPart.module.css');
const styles = {
  calender: 'calender_f3050b27',
  container: 'container_f3050b27',
  row: 'row_f3050b27',
  column: 'column_f3050b27',
  'ms-Grid': 'ms-Grid_f3050b27',
  title: 'title_f3050b27',
  subTitle: 'subTitle_f3050b27',
  description: 'description_f3050b27',
  button: 'button_f3050b27',
  label: 'label_f3050b27',
};

export default styles;
/* tslint:enable */