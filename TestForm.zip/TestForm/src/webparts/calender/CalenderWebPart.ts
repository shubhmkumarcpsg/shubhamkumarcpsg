import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './CalenderWebPart.module.scss';
import * as strings from 'CalenderWebPartStrings';
import 'jquery';
import 'moment';
import 'fullcalendar';
export interface ICalenderWebPartProps {
  description: string;
}

export default class CalenderWebPart extends BaseClientSideWebPart<ICalenderWebPartProps>{
   public render(): void {
    this.domElement.innerHTML = `
      <div class="${ styles.calender }">
      <link type="text/css" rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css" />
      <div id="calendar"></div>
      </div>`;


      (window as any).webAbsoluteUrl = this.context.pageContext.web.absoluteUrl;
      //require('./script');
  }
}
