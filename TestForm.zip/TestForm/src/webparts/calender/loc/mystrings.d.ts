declare interface ICalenderWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CalenderWebPartStrings' {
  const strings: ICalenderWebPartStrings;
  export = strings;
}
